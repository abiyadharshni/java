package abiya.com;
import java.util.Scanner;

public class Vowel {

	public static void main(String[] args) {
    char vowel;
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the vowel:");
    vowel=sc.next().charAt(0);
    
    switch(vowel) {
    case 'a':
    	System.out.println(vowel+"is a vowel");
    	break;
    case 'e':
    	System.out.println(vowel+"is a vowel");
    	break;
    case 'i':
    	System.out.println(vowel+"is a vowel");
    	break;
    case 'o':
    	System.out.println(vowel+"is a vowel");
    	break;
    case 'u':
    	System.out.println(vowel+"is a vowel");
    	break;
    default:
    	System.out.println("Not a vowel");
    }
    
    

	}

}
