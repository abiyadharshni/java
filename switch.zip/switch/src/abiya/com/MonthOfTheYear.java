package abiya.com;
import java.util.Scanner;

public class MonthOfTheYear {

	public static void main(String[] args) {
	String month;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the month:");
	month=sc.next();
	
	switch(month) {
	case "january":
		          System.out.println("First Month of the year");
		          break;
	case "February":
		          System.out.println("Second Month of the year");
                  break;
	case "march":
		          System.out.println("Third Month of the year");
		          break;
	case "april":
		          System.out.println("Fourth Month of the year");
		          break;
	case "may":
		          System.out.println("Fifth Month of the year");
		          break;
	case "june":
		          System.out.println("Sixth Month of the year");
	           	  break;
	case "july":
		          System.out.println("Seventh Month of the year");
		          break;
	case "august":
		     	  System.out.println("Eighth Month of the year");
		    	  break;
	case "september":
		          System.out.println("Ninth Month of the year");
		          break;
	case "october":
		          System.out.println("Tenth Month of the year");
		          break;
	case "november":
		          System.out.println("Eleventh Month of the year");
		          break;
	case "december":
		          System.out.println("Twelth Month of the year");
		          break;
    default:
    	      System.out.println("invalid month");
    
    
    
		        
		         
    
    
    
    
    
	}
	
	

	}

}
