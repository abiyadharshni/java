package abiya.com;
import java.util.Scanner;

public class Arithmetic {

	public static void main(String[] args) {
		int choice;
		float num1,num2,result;
		Scanner sc = new Scanner(System.in);
		System.out.println("************menu************");
		System.out.println("1.ADDITION");
		System.out.println("2.SUBTRACTION");
		System.out.println("3.MULTIPLICATION");
		System.out.println("4.DIVISION");
		System.out.println("Enter the choice:");
		choice=sc.nextInt();
		System.out.println("Enter two numbers:");
		num1=sc.nextFloat();
		num2=sc.nextFloat();
		switch(choice) {
		case 1:result=num1+num2;
		       System.out.println("sum="+result);
		       break;
		case 2:result=num1-num2;
	           System.out.println("difference="+result);
	           break;
		case 3:result=num1*num2;
	           System.out.println("product="+result);
	           break;
		case 4:if(num2==0) {
			System.out.println("divide by zero error");
		}
		else {
			result=num1/num2;
			System.out.println("quotient of"+num1+"and"+num2+"is"+result);
		}
		default:
	       System.out.println("invalid input");
	          
		       
		}
		
		
		
				
		
		
		

	}

}
