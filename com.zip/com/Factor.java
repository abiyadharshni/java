package abiya.com;

public class Factor {

	public static void main(String[] args) {
		int i,num=6;
		int s=0;
		for(i=1;i<=num;i++) {
			if(num%i==0)
			{
				System.out.println(i);
				s=s+i;
				
			}
				
			
		}
		System.out.println("sum of factor="+s);

	}

}
