package abiya.com;
import java.util.Scanner;


public class ReverseNumber {

	public static void main(String[] args) {
	     int num,digit;
	     Scanner sc=new Scanner(System.in);
	     
	     System.out.println("enter the number");
	     num=sc.nextInt();//123(input)  321(output)
	     /* digit=num%10;    //123%10
	     System.out.println(digit); //3
	     num=num/10; //123/10=12
	     digit=num%10; //digit=2
	     System.out.println(digit); //32
	     num=num/10; //12/10=1
	     digit=num%10; //12%10=1
	     System.out.println(digit); //321
	     num=num/10; //1/10=0  */
	     
        while(num!=0) {
        	digit=num%10;
        	System.out.print(digit);
        	num=num/10;
        }
	}

}
